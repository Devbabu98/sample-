var requestPayload = JSON.parse(request.content);
var iccid = context.getVariable('du.iccid');
var eid = context.getVariable('du.eid');
var matchingId = context.getVariable('du.matchingId');
var finalProfileStatusIndicator = context.getVariable('du.finalProfileStatusIndicator');
var operatorId = context.getVariable('du.operatorId');

if(!(iccid===null || iccid==="" || iccid === "null")){
    requestPayload.iccid = iccid; 
}
if(!(eid===null || eid==="" || eid === "null")){
    requestPayload.eid = eid; 
}
if(!(matchingId===null || matchingId==="" || matchingId === "null")){
    requestPayload.matchingId = matchingId; 
}
if(!(finalProfileStatusIndicator===null || finalProfileStatusIndicator==="" || finalProfileStatusIndicator === "null")){
    requestPayload.finalProfileStatusIndicator = finalProfileStatusIndicator; 
}
if(!(operatorId===null || operatorId==="" || operatorId === "null")){
    requestPayload.operatorId = operatorId; 
}

context.setVariable('request.content', JSON.stringify(requestPayload));