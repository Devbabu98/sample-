var requestPayload = JSON.parse(request.content);
var eid = context.getVariable('du.eid');
var iccid = context.getVariable('du.iccid');
var profileType = context.getVariable('du.profileType');
var operatorId = context.getVariable('du.operatorId');

if(!(eid===null || eid==="" || eid === "null")){
    requestPayload.eid = eid; 
}
if(!(iccid===null || iccid==="" || iccid === "null")){
    requestPayload.iccid = iccid; 
}
if(!(profileType===null || profileType==="" || profileType === "null")){
    requestPayload.profileType = profileType; 
}
if(!(operatorId===null || operatorId==="" || operatorId === "null")){
    requestPayload.operatorId = operatorId; 
}

context.setVariable('request.content', JSON.stringify(requestPayload));
