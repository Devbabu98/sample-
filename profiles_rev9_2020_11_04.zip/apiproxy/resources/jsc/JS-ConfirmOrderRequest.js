var requestPayload = JSON.parse(request.content);
var iccid = context.getVariable('du.iccid');
var eid = context.getVariable('du.eid');
var matchingId = context.getVariable('du.matchingId');
var confirmationCode = context.getVariable('du.confirmationCode');
var smdsAddress = context.getVariable('du.smdsAddress');
var releaseFlag = context.getVariable('du.releaseFlag');
var operatorId = context.getVariable('du.operatorId');

if(!(iccid===null || iccid==="" || iccid === "null")){
    requestPayload.iccid = iccid; 
}
if(!(eid===null || eid==="" || eid === "null")){
    requestPayload.eid = eid; 
}
if(!(matchingId===null || matchingId==="" || matchingId === "null")){
    requestPayload.matchingId = matchingId; 
}
if(!(confirmationCode===null || confirmationCode==="" || confirmationCode === "null")){
    requestPayload.confirmationCode = confirmationCode; 
}
if(!(smdsAddress===null || smdsAddress==="" || smdsAddress === "null")){
    requestPayload.smdsAddress = smdsAddress; 
}
if(!(releaseFlag===null || releaseFlag==="" || releaseFlag === "null")){
    requestPayload.releaseFlag = releaseFlag; 
}
if(!(operatorId===null || operatorId==="" || operatorId === "null")){
    requestPayload.operatorId = operatorId; 
}

context.setVariable('request.content', JSON.stringify(requestPayload));