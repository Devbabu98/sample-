 //retrieve the current operation in order to match to the flag
var ES2Path = context.getVariable('du.config.smdpTargetBasepathES2Standard');
var InventoryPath = context.getVariable('du.config.smdpTargetBasepathInventory');
var smdpUrl = context.getVariable('du.config.smdpTargetUrl');

var currentOp = context.getVariable('proxy.pathsuffix').substring(1);
var operation = currentOp.concat("_", context.getVariable('request.verb'));
        
context.setVariable('du.operation', operation);
context.setVariable('du.smdpUrl', smdpUrl + "/");

if(operation == 'profile_GET'){
    context.setVariable('du.config.smdpTargetBasePath', InventoryPath);
}

else{
    context.setVariable('du.config.smdpTargetBasePath', ES2Path);
}