var requestPayload = JSON.parse(request.content);
var iccid = context.getVariable('du.iccid');
var eid = context.getVariable('du.eid');
var targetState = context.getVariable('du.targetState');

if(!(iccid===null || iccid==="" || iccid === "null")){
    requestPayload.iccid = iccid; 
}
if(!(eid===null || eid==="" || eid === "null")){
    requestPayload.eid = eid; 
}
if(!(targetState===null || targetState==="" || targetState === "null")){
    requestPayload.targetState = targetState; 
}

context.setVariable('request.content', JSON.stringify(requestPayload));