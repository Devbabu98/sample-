var smdpUrl = context.getVariable('du.config.smdpTargetUrl');
var smdpTargetBasePath = context.getVariable('du.config.smdpTargetBasePath');
var SMDPpath = context.getVariable('du.SMDPpath');

context.setVariable('target.url', "https://" + smdpUrl + "/" + smdpTargetBasePath + SMDPpath);